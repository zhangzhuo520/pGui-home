#include "gearmanconnector.h"

GearmanConnector::GearmanConnector()
{
}

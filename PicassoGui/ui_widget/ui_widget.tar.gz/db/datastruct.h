#ifndef DATASTRUCT_H
#define DATASTRUCT_H

class datastruct
{
public:
    datastruct();
};

#endif // DATASTRUCT_H

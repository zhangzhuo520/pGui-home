#include "datastruct.h"

datastruct::datastruct()
{
}

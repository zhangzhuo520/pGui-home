#ifndef GEARMANCONNECTOR_H
#define GEARMANCONNECTOR_H

class GearmanConnector
{
public:
    GearmanConnector();
};

#endif // GEARMANCONNECTOR_H
